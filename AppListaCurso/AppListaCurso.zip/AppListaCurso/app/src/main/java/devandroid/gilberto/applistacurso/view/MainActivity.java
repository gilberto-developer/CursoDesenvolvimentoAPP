package devandroid.gilberto.applistacurso.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import devandroid.gilberto.applistacurso.R;
import devandroid.gilberto.applistacurso.model.Pessoa;

public class MainActivity extends AppCompatActivity {


    // declarando o objeto pessoa
    Pessoa pessoa;

    String dadosPessoa;
    EditText editPrimeiroNome;
    EditText editSobrenomeAluno;
    EditText editNomeCurso;
    EditText editTelefoneContato;
    Button btnLimpar;
    Button btnFinalizar;
    Button btnSalvar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // criando o objeto pessoa
        pessoa = new Pessoa();
        pessoa.setPrimeiroNome("Gilberto");
        pessoa.setSobreNome("Santos");
        pessoa.setCursoDesejado("Análise de dados");
        pessoa.setTelefoneContato("71-988825988");

        editPrimeiroNome=findViewById(R.id.editPrimeiroNome);
        editSobrenomeAluno=findViewById(R.id.editSobrenomeAluno);
        editNomeCurso=findViewById(R.id.editNomeCurso);
        editTelefoneContato=findViewById(R.id.editTelefoneContato);

        btnLimpar = findViewById(R.id.btnLimpar);
        btnFinalizar = findViewById(R.id.btnFinalizar);
        btnSalvar = findViewById(R.id.btnSalvar);

        editPrimeiroNome.setText(pessoa.getPrimeiroNome());
        editSobrenomeAluno.setText(pessoa.getSobreNome());
        editNomeCurso.setText(pessoa.getCursoDesejado());
        editTelefoneContato.setText(pessoa.getTelefoneContato());

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             editPrimeiroNome.setText("");
             editSobrenomeAluno.setText("");
             editNomeCurso.setText("");
             editTelefoneContato.setText("");


            }
        });
        btnFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Volte sempre",Toast.LENGTH_LONG).show();
                finish();
            }
        });

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pessoa.setPrimeiroNome(editPrimeiroNome.getText().toString());
                pessoa.setSobreNome(editSobrenomeAluno.getText().toString());
                pessoa.setCursoDesejado(editNomeCurso.getText().toString());
                pessoa.setTelefoneContato(editTelefoneContato.getText().toString());

                Toast.makeText(MainActivity.this,"Salvo! " + pessoa.toString(),Toast.LENGTH_LONG).show();

            }
        });
    }
}